# -*- coding: utf-8 -*-
"""
Created on Wed Jan 18 10:40:14 2017

@author: pk3014
"""

import numpy as np

a=np.array([1,2,5,3,4,8,6])
b=np.array([5,5,6,4,5,3,3])
c= np.where(a>b)
print c[0][0]